package es.studium.practica5ad;

public class Habitacion {

	// Atributo
	private String nombreHabitacion;
	private int pisoHabitacion;
	private boolean tieneVentana;
	private Persona persona;

	// Constructores
	// Constructor vacío o por defecto
	public Habitacion() {
		nombreHabitacion = "";
		pisoHabitacion = 0;
		tieneVentana = false;
		persona = new Persona();
	}

	// Constructor por parámetros
	public Habitacion(String nombreHabitacion, int pisoHabitacion, boolean tieneVentana, Persona persona) {
		this.nombreHabitacion = nombreHabitacion;
		this.pisoHabitacion = pisoHabitacion;
		this.tieneVentana = tieneVentana;
		this.persona = persona;
	}

	// Métodos get y set
	public String getNombreHabitacion() {
		return nombreHabitacion;
	}

	public void setNombreHabitacion(String nombreHabitacion) {
		this.nombreHabitacion = nombreHabitacion;
	}

	public int getPisoHabitacion() {
		return pisoHabitacion;
	}

	public void setPisoHabitacion(int pisoHabitacion) {
		this.pisoHabitacion = pisoHabitacion;
	}

	public boolean isTieneVentana() {
		return tieneVentana;
	}

	public void setTieneVentana(boolean tieneVentana) {
		this.tieneVentana = tieneVentana;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Habitacion [nombreHabitacion=" + nombreHabitacion + ", pisoHabitacion=" + pisoHabitacion + ""
				+ ", tieneVentana=" + tieneVentana + ", persona=" + persona + "]";
	}
}
