package es.studium.practica5ad;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Principal {
	public static void main(String[] args) {
		/*
		 * Abrimos el contenedor de IoC indicando la ruta exacta de donde se encuentra
		 * el fichero beans.xml
		 */
		ApplicationContext context = new ClassPathXmlApplicationContext("es/studium/xml/beans.xml");
		/* Obtenemos un bean de tipo Casa */
		Casa casa = context.getBean("Casa", Casa.class);
		/*
		 * Mostramos los valores de los atributos dados en el fichero beans.xml, que son
		 * los valores por defecto
		 */
		System.out.println("Datos de la casa: " + casa.toString());
		/* Cerramos el contexto */
		((ConfigurableApplicationContext) context).close();
	}
}
