package es.studium.practica5ad;

public class Persona {

	// Atributo
	private String nombre;

	// Constructores
	// Constructor vacío o por defecto
	public Persona() {
		nombre = "";
	}

	// Constructor por parámetros
	public Persona(String nombre) {
		this.nombre = nombre;
	}

	// Métodos get y set
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + "]";
	}
}
